const express = require('express');
const app = express();
const db = require('./db');

app.set('view engine', 'ejs'); // Configurar EJS como motor de vistas
app.use(express.urlencoded({ extended: true })); // Para manejar datos de formularios
app.use(express.json());
app.use(express.static('public')); // Carpeta para archivos estáticos (CSS, imágenes, etc.)

// Ruta para la interfaz principal
app.get('/', (req, res) => {
    db.query('SELECT * FROM usuarios', (error, results) => {
        if (error) {
            console.error('Error ejecutando la consulta:', error);
            res.status(500).send('Error en el servidor');
        } else {
            res.render('index', { usuarios: results }); // Renderizar la vista 'index.ejs'
        }
    });
});

// Ruta para agregar usuarios
app.post('/usuarios', (req, res) => {
    const { nombre, email } = req.body;
    const query = 'INSERT INTO usuarios (nombre, email) VALUES (?, ?)';
    db.query(query, [nombre, email], (error) => {
        if (error) {
            console.error('Error ejecutando la consulta:', error);
            res.status(500).send('Error en el servidor');
        } else {
            res.redirect('/'); // Redirigir a la página principal
        }
    });
});

// Ruta para eliminar usuarios
app.post('/usuarios/:id/eliminar', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM usuarios WHERE id = ?';
    db.query(query, [id], (error) => {
        if (error) {
            console.error('Error ejecutando la consulta:', error);
            res.status(500).send('Error en el servidor');
        } else {
            res.redirect('/'); // Redirigir a la página principal
        }
    });
});

// Ruta para actualizar usuarios
app.post('/usuarios/:id/actualizar', (req, res) => {
    const { id } = req.params; // ID del usuario desde la URL
    const { nombre, email } = req.body; // Datos del formulario

    // Consulta para actualizar el usuario
    const query = 'UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?';

    db.query(query, [nombre, email, id], (error) => {
        if (error) {
            console.error('Error ejecutando la consulta:', error);
            res.status(500).send('Error en el servidor');
        } else {
            res.redirect('/'); // Redirigir a la página principal después de actualizar
        }
    });
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
