const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();
const methodOverride = require('method-override');



// Configuración de EJS y archivos estáticos
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
// Importar rutas
const routes = require('./routes/routes');
app.use('/', routes);
// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, () => {
 console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
app.use(express.json());

