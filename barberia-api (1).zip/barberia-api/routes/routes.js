const express = require('express');
const router = express.Router();
const db = require('../db');

// Página principal: lista de clientes y cortes
router.get('/', (req, res) => {
  const clientesQuery = 'SELECT * FROM clientes';
  const cortesQuery = 'SELECT * FROM cortes';
  db.query(clientesQuery, (err, clientes) => {
    if (err) throw err;
    db.query(cortesQuery, (err, cortes) => {
      if (err) throw err;
      res.render('index', { clientes, cortes });
    });
  });
});

// Agregar cliente
router.post('/clientes', (req, res) => {
  const { nombre, correo, telefono } = req.body;
  const sql = 'INSERT INTO clientes (nombre, correo, telefono) VALUES (?, ?, ?)';
  db.query(sql, [nombre, correo, telefono], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Agregar corte
router.post('/cortes', (req, res) => {
  const { id_cliente, estilo, duracion_min, precio } = req.body;
  const sql = 'INSERT INTO cortes (id_cliente, estilo, duracion_min, precio) VALUES (?, ?, ?, ?)';
  db.query(sql, [id_cliente, estilo, duracion_min, precio], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Eliminar corte
router.delete('/cortes/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM cortes WHERE id = ?';
  db.query(sql, [id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Eliminar cliente
router.delete('/clientes/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM clientes WHERE id = ?';
  db.query(sql, [id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Mostrar formulario de edición de cliente
router.get('/clientes/:id/edit', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM clientes WHERE id = ?';
  db.query(sql, [id], (err, cliente) => {
    if (err) throw err;
    res.render('edit_cliente', { cliente: cliente[0] });
  });
});

// Actualizar cliente
router.put('/clientes/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, correo, telefono } = req.body;
  const sql = 'UPDATE clientes SET nombre = ?, correo = ?, telefono = ? WHERE id = ?';
  db.query(sql, [nombre, correo, telefono, id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Mostrar formulario de edición de corte
router.get('/cortes/:id/edit', (req, res) => {
  const { id } = req.params;
  const sqlCorte = 'SELECT * FROM cortes WHERE id = ?';
  const sqlClientes = 'SELECT * FROM clientes'; // Cargar los clientes para el select
  db.query(sqlCorte, [id], (err, corte) => {
    if (err) throw err;
    if (!corte || corte.length === 0) {
      return res.status(404).send('Corte no encontrado');
    }
    db.query(sqlClientes, (err, clientes) => {
      if (err) throw err;
      res.render('edit_corte', { corte: corte[0], clientes });
    });
  });
});

// Actualizar corte
router.put('/cortes/:id', (req, res) => {
  const { id } = req.params;
  const { id_cliente, estilo, duracion_min, precio } = req.body;
  const sql = 'UPDATE cortes SET id_cliente = ?, estilo = ?, duracion_min = ?, precio = ? WHERE id = ?';
  db.query(sql, [id_cliente, estilo, duracion_min, precio, id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});
// Actualizar cliente (con PUT)
router.put('/clientes/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, correo, telefono } = req.body;
  const sql = 'UPDATE clientes SET nombre = ?, correo = ?, telefono = ? WHERE id = ?';
  db.query(sql, [nombre, correo, telefono, id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});


module.exports = router;
