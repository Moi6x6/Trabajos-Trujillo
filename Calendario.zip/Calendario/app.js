const express = require('express');
const path = require('path'); // Asegúrate de importar el módulo path
const app = express();
const port = 3008;

// Configuración del motor de vistas y archivos estáticos
app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public')); // Servir archivos estáticos desde la carpeta "public"

// Resto de la configuración del servidor y rutas
let eventos = [
    { nombre: 'Reunión de equipo', fecha: '2023-11-10', descripcion: 'Reunión semanal de planificación.' },
    { nombre: 'Conferencia', fecha: '2023-11-15', descripcion: 'Conferencia anual de tecnología.' }
];

// Ruta principal para ver el calendario de eventos
app.get('/', (req, res) => {
    eventos = eventos.sort((a, b) => new Date(a.fecha) - new Date(b.fecha)); // Ordenar por fecha
    res.render('index', { eventos });
});



// Ruta para ver detalles de un evento específico
app.get('/evento/:nombre', (req, res) => {
    const nombreEvento = req.params.nombre;
    const evento = eventos.find(e => e.nombre === nombreEvento);
    if (evento) {
        res.render('detalle', { evento });
    } else {
        res.status(404).send('Evento no encontrado');
    }
});

// Ruta para agregar nuevos eventos
app.post('/agregar', (req, res) => {
    const { nombre, fecha, descripcion } = req.body;
    const fechaActual = new Date();
    const fechaIngresada = new Date(fecha);

    if (fechaIngresada > fechaActual) {
        eventos.push({ nombre, fecha, descripcion });
        res.redirect('/');
    } else {
        res.send("La fecha debe ser posterior a la fecha del dia de hoy, seleccione otro dia porfavor.");
    }
});

app.listen(port, () => {
    console.log(`Servidor en ejecución en http://localhost:${port}`);
});
